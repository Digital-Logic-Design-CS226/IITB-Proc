# IITB-Proc

Change the file path and number of lines (these are hardcoded) in instruction memory.vhd according to testing setup.

FSM, RTL and Components are present in Theory Folder.

Team Roll numbers : 
Dhruva Dhingra : 190070020
Aman Yadav : 190050013
Amit Kumar Mallik : 19D070007
Amit Meena : 190050014

Group TAs and Numbers :

Group 7 : Aman Yadav (190050013) and Dhruva Dhingra (190070020)
Group 13 : Amit Kumar Mallik (19D070007) and Amit Meena (190050014)